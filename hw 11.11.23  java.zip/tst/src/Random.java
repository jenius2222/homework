
    import java.util.Random;
class PrimitiveTypesExample {
        public static void main(String[] args) { Random random = new Random();

            int intValue = random.nextInt();
            byte byteValue = (byte) random.nextInt();
            short shortValue = (short) random.nextInt();
            long longValue = random.nextLong();
            float floatValue = random.nextFloat();
            double doubleValue = random.nextDouble();
            char charValue = (char) (random.nextInt(25) + 'a');

            System.out.println("int: " + intValue);
            System.out.println("byte: " + byteValue);
            System.out.println("short: " + shortValue);
            System.out.println("long: " + longValue);
            System.out.println("float: " + floatValue);
            System.out.println("double: " + doubleValue);
            System.out.println("char: " + charValue);

            String stringValue = String.valueOf(random.nextInt(4000)); // Пример для строки с числовым значением
            System.out.println("String: " + stringValue);
        }
    }

