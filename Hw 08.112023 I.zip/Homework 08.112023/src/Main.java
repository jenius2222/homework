public class Main {
    public static void main(String[] args) {
        char ch = 'G';
        System.out.println(ch);
        int num1 = 85;
        System.out.println(num1);
        byte num2 = 4;
        System.out.println(num2);
        short num3 = 56;
        System.out.println(num3);
        float num4 = 4.7333436f;
        System.out.println(num4);
        double num5 = 4.355453532;
        System.out.println(num5);
    }
}